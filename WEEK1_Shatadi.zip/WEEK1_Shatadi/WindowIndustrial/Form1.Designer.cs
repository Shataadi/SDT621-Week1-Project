﻿namespace WindowIndustrial
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label4 = new Label();
            txtName = new TextBox();
            txtAge = new TextBox();
            btnSubmit = new Button();
            label5 = new Label();
            txtGrade = new TextBox();
            label6 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(78, 102);
            label1.Name = "label1";
            label1.Size = new Size(140, 20);
            label1.TabIndex = 0;
            label1.Text = "Enter student name:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(78, 153);
            label2.Name = "label2";
            label2.Size = new Size(128, 20);
            label2.TabIndex = 1;
            label2.Text = "Enter student age:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(78, 212);
            label4.Name = "label4";
            label4.Size = new Size(174, 20);
            label4.TabIndex = 3;
            label4.Text = "Enter your grade (0-100):";
            // 
            // txtName
            // 
            txtName.Location = new Point(258, 99);
            txtName.Name = "txtName";
            txtName.Size = new Size(217, 27);
            txtName.TabIndex = 4;
            // 
            // txtAge
            // 
            txtAge.Location = new Point(258, 153);
            txtAge.Name = "txtAge";
            txtAge.Size = new Size(217, 27);
            txtAge.TabIndex = 5;
            // 
            // btnSubmit
            // 
            btnSubmit.Location = new Point(208, 275);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(94, 29);
            btnSubmit.TabIndex = 8;
            btnSubmit.Text = "Check";
            btnSubmit.UseVisualStyleBackColor = true;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Showcard Gothic", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(96, 32);
            label5.Name = "label5";
            label5.Size = new Size(579, 46);
            label5.TabIndex = 9;
            label5.Text = "Student Profile Processor";
            // 
            // txtGrade
            // 
            txtGrade.Location = new Point(258, 209);
            txtGrade.Name = "txtGrade";
            txtGrade.Size = new Size(209, 27);
            txtGrade.TabIndex = 10;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(556, 260);
            label6.Name = "label6";
            label6.Size = new Size(50, 20);
            label6.TabIndex = 11;
            label6.Text = "label6";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label6);
            Controls.Add(txtGrade);
            Controls.Add(label5);
            Controls.Add(btnSubmit);
            Controls.Add(txtAge);
            Controls.Add(txtName);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label4;
        private TextBox txtName;
        private TextBox txtAge;
        private Button btnSubmit;
        private Label label5;
        private TextBox txtGrade;
        private Label label6;
    }
}

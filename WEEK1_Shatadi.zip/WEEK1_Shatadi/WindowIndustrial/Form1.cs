﻿namespace WindowIndustrial
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            int age = int.Parse(txtAge.Text);      // type casting
            double grade = double.Parse(txtGrade.Text);

            // Build the output message
            string result = "Student: " + name + "\n";
            result += "Age: " + age + "\n";
            result += "Grade: " + grade + "%\n";

            if (grade >= 50)
                result += "Status: Ready ";
            else
                result += "Status: Needs Improvement ";

            // Show it in the label
            label6.Text = result;
        }
    }
    }


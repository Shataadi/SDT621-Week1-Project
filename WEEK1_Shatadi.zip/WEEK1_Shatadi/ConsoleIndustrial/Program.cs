﻿// See https://aka.ms/new-console-template for more information
class StudentProfileProcessor
{
    static string companyName = "Kitumaini Digital Solutions";

    static void Main(string[] args)
    {
        Console.WriteLine("====================================");
        Console.WriteLine("  Welcome to " + companyName);
        Console.WriteLine("  Student Readiness Capture System");
        Console.WriteLine("====================================\n");

        Console.Write("Enter student name: ");
        string studentName = Console.ReadLine();  

        Console.Write("Enter student age: ");
        int studentAge = int.Parse(Console.ReadLine()); 

        Console.Write("Enter student number: ");
        string studentNumber = Console.ReadLine();

        Console.Write("Enter your grade (0-100): ");
        double grade = double.Parse(Console.ReadLine());  

        // Call a method to display the profile
        DisplayProfile(studentName, studentAge, studentNumber);

        CheckReadiness(grade);

    }

    static void DisplayProfile(string name, int age, string number)
    {
        Console.WriteLine("\n--- Student Profile ---");
        Console.WriteLine("Name: " + name);
        Console.WriteLine("Age: " + age);
        Console.WriteLine("Student Number: " + number);
    }

    static void CheckReadiness(double grade)
    {
        string status;

        if (grade >= 50)
        {
            status = "Ready ";
        }
        else
        {
            status = "Needs Improvement ✗";
        }

        Console.WriteLine("\n--- Readiness Report ---");
        Console.WriteLine("Grade: " + grade + "%");
        Console.WriteLine("Status: " + status);
    }

    static void CheckReadiness(double grade, string subject)
    {
        Console.WriteLine("\n--- Readiness Report for " + subject + " ---");
        Console.WriteLine("Grade:  " + grade + "%");

        if (grade >= 50)
            Console.WriteLine("Status: Passed ");
        else
            Console.WriteLine("Status: Failed ");
    }
}
